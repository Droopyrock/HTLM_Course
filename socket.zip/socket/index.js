const express = require ('express');
const app = express();
const http = require ('http');
const server = http.createServer(app);
const {Server} = require("socket.io");
const io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  app.use('/css', express.static(__dirname + '/css'));
  app.get('/', (req, res) => {
    res.sendFile(__dirname+'/index.html')
});

  io.on('connection', (socket)=> { 
    console.log('le client cest connecte');
    socket.on('message', (msg)=>{
        io.emit('message', msg);
    });
    socket.on('disconnect', ()=> { 
        console.log('le client cest deconnecte');
  });
});

server.listen(3000, ()=> {
    console.log('Le serveur est en ecoute sur le port3000');
});